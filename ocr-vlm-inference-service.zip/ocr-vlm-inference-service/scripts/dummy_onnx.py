"""Build a tiny valid ONNX classifier (no PyTorch needed) for tests, demos and CI.

input [N,3,224,224] -> global mean per channel -> linear(3->C) -> logits [N,C]
"""
import argparse

import numpy as np
import onnx
from onnx import TensorProto, helper


def build(path: str, n_classes: int = 4, seed: int = 0) -> str:
    rng = np.random.default_rng(seed)
    w = rng.normal(size=(3, n_classes)).astype(np.float32)
    b = rng.normal(size=(n_classes,)).astype(np.float32)
    nodes = [
        helper.make_node("ReduceMean", ["input"], ["pooled"], axes=[2, 3], keepdims=0),
        helper.make_node("MatMul", ["pooled", "W"], ["mm"]),
        helper.make_node("Add", ["mm", "B"], ["logits"]),
    ]
    graph = helper.make_graph(
        nodes, "tiny_classifier",
        [helper.make_tensor_value_info("input", TensorProto.FLOAT, ["batch", 3, 224, 224])],
        [helper.make_tensor_value_info("logits", TensorProto.FLOAT, ["batch", n_classes])],
        initializer=[helper.make_tensor("W", TensorProto.FLOAT, w.shape, w.flatten()),
                     helper.make_tensor("B", TensorProto.FLOAT, b.shape, b.flatten())],
    )
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 13)])
    model.ir_version = 8
    onnx.checker.check_model(model)
    onnx.save(model, path)
    return path


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="models/dummy_classifier.onnx")
    a = ap.parse_args()
    import os

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    print("wrote", build(a.out))
