"""Concurrent load test against a running service.

    python scripts/load_test.py --url http://localhost:8000/v1/classify --image sample.png --n 200 --concurrency 16
"""
import argparse
import asyncio
import time

import httpx
import numpy as np


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://localhost:8000/v1/classify")
    ap.add_argument("--image", required=True)
    ap.add_argument("--n", type=int, default=100)
    ap.add_argument("--concurrency", type=int, default=8)
    ap.add_argument("--api-key", default="")
    a = ap.parse_args()

    data = open(a.image, "rb").read()
    mime = "image/png" if a.image.lower().endswith("png") else "image/jpeg"
    headers = {"x-api-key": a.api_key} if a.api_key else {}
    sem, lats, errors = asyncio.Semaphore(a.concurrency), [], 0

    async with httpx.AsyncClient(timeout=120) as c:
        async def one():
            nonlocal errors
            async with sem:
                t0 = time.perf_counter()
                try:
                    r = await c.post(a.url, files={"file": ("x", data, mime)}, headers=headers)
                    errors += r.status_code >= 400
                except httpx.HTTPError:
                    errors += 1
                lats.append((time.perf_counter() - t0) * 1000)

        t0 = time.perf_counter()
        await asyncio.gather(*[one() for _ in range(a.n)])
        wall = time.perf_counter() - t0

    l = np.array(lats)
    print(f"requests={a.n} concurrency={a.concurrency} errors={errors} wall={wall:.2f}s rps={a.n / wall:.1f}")
    print(f"latency ms: p50={np.percentile(l, 50):.1f} p95={np.percentile(l, 95):.1f} p99={np.percentile(l, 99):.1f}")


asyncio.run(main())
