"""Export a PyTorch document classifier to TorchScript and ONNX, then verify numerical parity.

    python scripts/export_onnx.py --out models/ --classes 4
    python scripts/export_onnx.py --ckpt my_weights.pt --out models/

Replace `DocClassifier` with your fine-tuned model (e.g. a torchvision ResNet) - the export and
parity-check code stays the same. Input name `input`, output name `logits` (matches Triton config).
"""
import argparse
import os

import numpy as np
import onnxruntime as ort
import torch
import torch.nn as nn


class DocClassifier(nn.Module):
    """Small CNN, enough to demonstrate the export path."""

    def __init__(self, n_classes: int = 4):
        super().__init__()
        def block(i, o):
            return nn.Sequential(nn.Conv2d(i, o, 3, padding=1), nn.BatchNorm2d(o), nn.ReLU(), nn.MaxPool2d(2))
        self.features = nn.Sequential(block(3, 16), block(16, 32), block(32, 64), block(64, 128))
        self.head = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(128, n_classes))

    def forward(self, x):
        return self.head(self.features(x))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="models")
    ap.add_argument("--classes", type=int, default=4)
    ap.add_argument("--ckpt", default=None)
    ap.add_argument("--size", type=int, default=224)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    model = DocClassifier(a.classes)
    if a.ckpt:
        model.load_state_dict(torch.load(a.ckpt, map_location="cpu"))
    model.eval()
    dummy = torch.randn(2, 3, a.size, a.size)

    ts_path = os.path.join(a.out, "doc_classifier.pt")
    torch.jit.trace(model, dummy).save(ts_path)

    onnx_path = os.path.join(a.out, "doc_classifier.onnx")
    torch.onnx.export(
        model, dummy, onnx_path, input_names=["input"], output_names=["logits"],
        dynamic_axes={"input": {0: "batch"}, "logits": {0: "batch"}}, opset_version=17,
    )

    # parity check: PyTorch vs TorchScript vs ONNX Runtime
    x = torch.randn(5, 3, a.size, a.size)
    with torch.no_grad():
        ref = model(x).numpy()
        ts = torch.jit.load(ts_path)(x).numpy()
    sess = ort.InferenceSession(onnx_path, providers=["CPUExecutionProvider"])
    ox = sess.run(None, {"input": x.numpy()})[0]
    print("max |torch - torchscript| =", float(np.abs(ref - ts).max()))
    print("max |torch - onnx|        =", float(np.abs(ref - ox).max()))
    assert np.allclose(ref, ox, atol=1e-4), "ONNX output diverges from PyTorch"
    print("OK ->", ts_path, onnx_path)


if __name__ == "__main__":
    main()
