"""Profile an ONNX model: latency (p50/p95) and throughput per batch size, per execution provider.

    python scripts/benchmark_inference.py --model models/doc_classifier.onnx --providers CPUExecutionProvider CUDAExecutionProvider
"""
import argparse
import json
import time

import numpy as np
import onnxruntime as ort


def bench(model: str, provider: str, batch: int, iters: int = 30, warmup: int = 5, size: int = 224):
    sess = ort.InferenceSession(model, providers=[provider])
    name = sess.get_inputs()[0].name
    x = np.random.rand(batch, 3, size, size).astype(np.float32)
    for _ in range(warmup):
        sess.run(None, {name: x})
    times = []
    for _ in range(iters):
        t0 = time.perf_counter()
        sess.run(None, {name: x})
        times.append(time.perf_counter() - t0)
    t = np.array(times) * 1000
    return {
        "provider": provider, "batch": batch,
        "p50_ms": float(np.percentile(t, 50)), "p95_ms": float(np.percentile(t, 95)),
        "throughput_img_s": float(batch / (t.mean() / 1000)),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--providers", nargs="+", default=["CPUExecutionProvider"])
    ap.add_argument("--batches", nargs="+", type=int, default=[1, 4, 8, 16, 32])
    ap.add_argument("--iters", type=int, default=30)
    ap.add_argument("--out", default="benchmark.json")
    a = ap.parse_args()

    avail = ort.get_available_providers()
    rows = []
    print(f"{'provider':24s}{'batch':>6s}{'p50 ms':>10s}{'p95 ms':>10s}{'img/s':>10s}")
    for p in a.providers:
        if p not in avail:
            print(f"skip {p}: not available (have {avail})")
            continue
        for b in a.batches:
            r = bench(a.model, p, b, a.iters)
            rows.append(r)
            print(f"{p:24s}{b:6d}{r['p50_ms']:10.2f}{r['p95_ms']:10.2f}{r['throughput_img_s']:10.1f}")
    json.dump(rows, open(a.out, "w"), indent=2)


if __name__ == "__main__":
    main()
