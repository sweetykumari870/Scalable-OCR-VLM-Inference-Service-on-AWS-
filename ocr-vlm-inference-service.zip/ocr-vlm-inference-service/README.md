# OCR & Vision-Language Model Inference Service

A production-style inference service for document AI: OCR, batched document classification (ONNX Runtime)
and VLM extraction (vLLM), packaged with Docker and deployable on AWS (ECR + ECS) with logging, metrics and PII safeguards.

**Stack:** Python, FastAPI, Docker, ONNX / TorchScript, ONNX Runtime, vLLM, NVIDIA Triton, AWS (S3, ECR, ECS, Secrets Manager, IAM, CloudWatch), Prometheus

## Architecture

```
                 ┌──────────────────────── FastAPI service ────────────────────────┐
 client ─HTTP──► │ auth (X-API-Key) → validation (type/size/pixels) → metrics+logs │
                 │                                                                 │
                 │  /v1/ocr       → thread pool (bounded) → Tesseract              │
                 │  /v1/classify  → MicroBatcher ──► ONNX Runtime (GPU or CPU)     │
                 │  /v1/vlm/extract → async HTTP ──► vLLM (OpenAI-compatible API)  │
                 │  /health  /ready  /metrics (Prometheus)                         │
                 └─────────────────────────────────────────────────────────────────┘
```

| Concern | Where |
|---|---|
| **Dynamic batching** (collect up to N requests or T ms, one model call, fan results out) | `app/batcher.py`; Triton equivalent in `deploy/triton/.../config.pbtxt` |
| **CPU vs GPU inference** (execution-provider fallback, `/ready` reports the active provider) | `app/backends.py`, `scripts/benchmark_inference.py` |
| **Export + parity check** (PyTorch → TorchScript + ONNX, asserts outputs match) | `scripts/export_onnx.py` |
| **VLM serving** (vLLM, image sent as base64 data-URL, upstream errors → 502/504) | `app/vlm.py`, `docker-compose.yml` |
| **Monitoring** (latency histogram, throughput, failures, in-flight, batch-size, model time) | `app/metrics.py` → `/metrics`; JSON logs in `app/logging_conf.py` |
| **Security / governance** (API key, upload limits, no raw text in logs, optional PII masking) | `app/main.py`, `app/pii.py`, `deploy/aws/iam-task-role-policy.json` |
| **AWS deployment** (ECR push, ECS GPU task def, Secrets Manager, CloudWatch alarms) | `deploy/aws/*` |

## Quick start (CPU, no GPU needed)

```bash
sudo apt-get install tesseract-ocr                 # macOS: brew install tesseract
pip install -r requirements-dev.txt
pytest -q                                           # 13 tests

python scripts/dummy_onnx.py --out models/classifier.onnx   # tiny stand-in model
CLASSIFIER_PATH=models/classifier.onnx ONNX_PROVIDERS=CPUExecutionProvider \
  uvicorn app.main:app --port 8000

curl -F "file=@invoice.png;type=image/png" "localhost:8000/v1/ocr?mask=true"
curl -F "file=@invoice.png;type=image/png" localhost:8000/v1/classify
```

Swap in a real model: `pip install torch && python scripts/export_onnx.py --ckpt weights.pt --out models/`.

## Docker

```bash
docker build -t ocr-vlm-inference .                         # CPU
docker build -f Dockerfile.gpu -t ocr-vlm-inference:gpu .   # GPU (docker run --gpus all)
docker compose up --build                                   # API + vLLM (needs NVIDIA GPU)
```

## Benchmark and load test

```bash
# per-provider, per-batch-size latency (p50/p95) and throughput
python scripts/benchmark_inference.py --model models/classifier.onnx \
    --providers CPUExecutionProvider CUDAExecutionProvider

# concurrent HTTP load against a running service
python scripts/load_test.py --url http://localhost:8000/v1/classify --image invoice.png --n 200 --concurrency 16
```

Smoke test I ran on a CPU laptop-class sandbox (tiny stand-in ONNX model, so this only shows the batching mechanics, not real model speed):
200 requests at concurrency 16 → 0 errors, ~75 req/s, p95 277 ms. The batcher served them in 33 batches (~6 requests/batch).
**Run the benchmark with your real model on your GPU and record numbers here.**

## Deploy to AWS

1. Create: ECR repo, ECS cluster with a GPU EC2 capacity provider, Secrets Manager secret `ocr-vlm/api-key`, task + execution IAM roles (policy in `deploy/aws/iam-task-role-policy.json`), an ALB in front of the service.
2. `AWS_REGION=ap-south-1 AWS_ACCOUNT_ID=123456789012 ./deploy/aws/deploy.sh`
3. `SNS_TOPIC_ARN=... AWS_REGION=... ./deploy/aws/cloudwatch-alarms.sh` for 5xx and slow-request alarms.

Cost levers: batch more (`BATCH_MAX_SIZE`, `BATCH_MAX_WAIT_MS`), right-size the GPU instance from the benchmark, scale in on low `http_in_flight_requests`, and use Spot for non-latency-critical batch workloads.

## Status of each part

| Part | Verified |
|---|---|
| API, auth, validation, batcher, ONNX backend, VLM proxy (mocked upstream), PII masking, metrics | Unit-tested (13 tests) and exercised on a live uvicorn server with real Tesseract |
| Benchmark script | Run on CPU. GPU path not run |
| `export_onnx.py`, Dockerfiles, compose, Triton config, ECS/IAM JSON, shell scripts | JSON/YAML/bash syntax checked only. **Not executed** (needs PyTorch, Docker, GPU and an AWS account). Test them in your environment |
