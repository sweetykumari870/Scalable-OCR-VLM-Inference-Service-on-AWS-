import asyncio
import io
import json

import cv2
import httpx
import numpy as np
import pytest
from fastapi.testclient import TestClient

import dummy_onnx
from app.backends import OnnxClassifier
from app.batcher import MicroBatcher
from app.config import Settings
from app.main import create_app
from app.pii import mask_pii
from app.vlm import VLMClient


def png_bytes(w=200, h=100, color=255):
    img = np.full((h, w, 3), color, np.uint8)
    cv2.putText(img, "INVOICE 123", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
    return cv2.imencode(".png", img)[1].tobytes()


class FakeOCR:
    name = "fake"

    def run(self, image, preprocess=True):
        return {"text": "PAN ABCDE1234F total 500", "n_words": 4, "mean_conf": 0.9}


@pytest.fixture(scope="module")
def onnx_path(tmp_path_factory):
    return dummy_onnx.build(str(tmp_path_factory.mktemp("m") / "dummy.onnx"))


@pytest.fixture()
def clf(onnx_path):
    return OnnxClassifier(onnx_path, ["invoice", "bank_statement", "id_card", "salary_slip"], "CPUExecutionProvider")


def make_client(clf=None, vlm=None, **kw):
    s = Settings(**kw)
    return TestClient(create_app(s, ocr_backend=FakeOCR(), classifier=clf, vlm_client=vlm))


# ----------------------------------------------------------------------------- batcher
def test_batcher_groups_requests_and_preserves_order():
    sizes = []

    def fn(items):
        sizes.append(len(items))
        return [i * 2 for i in items]

    async def go():
        b = MicroBatcher(fn, max_batch_size=8, max_wait_ms=30)
        await b.start()
        res = await asyncio.gather(*[b.submit(i) for i in range(20)])
        await b.stop()
        return res

    res = asyncio.run(go())
    assert res == [i * 2 for i in range(20)]
    assert max(sizes) <= 8 and max(sizes) > 1 and sum(sizes) == 20


def test_batcher_propagates_errors():
    def boom(items):
        raise RuntimeError("model crashed")

    async def go():
        b = MicroBatcher(boom, max_wait_ms=5)
        await b.start()
        try:
            await b.submit(1)
        finally:
            await b.stop()

    with pytest.raises(RuntimeError):
        asyncio.run(go())


# ----------------------------------------------------------------------------- backends
def test_onnx_classifier_batch(clf):
    imgs = [np.full((50, 80, 3), v, np.uint8) for v in (0, 128, 255)]
    out = clf.predict_batch(imgs)
    assert len(out) == 3
    for o in out:
        assert o["label"] in clf.labels and 0 <= o["confidence"] <= 1
        assert sum(o["scores"].values()) == pytest.approx(1.0, abs=1e-5)


# ----------------------------------------------------------------------------- API
def test_health_ready_metrics(clf):
    with make_client(clf) as c:
        assert c.get("/health").json() == {"status": "ok"}
        r = c.get("/ready").json()
        assert r["classifier"] is True and r["vlm"] is False
        c.post("/v1/ocr", files={"file": ("a.png", png_bytes(), "image/png")})
        m = c.get("/metrics").text
        assert 'http_requests_total{endpoint="/v1/ocr",status="200"} 1.0' in m


def test_ocr_and_pii_masking():
    with make_client() as c:
        r = c.post("/v1/ocr?mask=true", files={"file": ("a.png", png_bytes(), "image/png")})
        assert r.status_code == 200 and "[PAN]" in r.json()["text"]
        raw = c.post("/v1/ocr", files={"file": ("a.png", png_bytes(), "image/png")}).json()["text"]
        assert "ABCDE1234F" in raw


def test_classify_concurrent_requests_are_batched(clf):
    with make_client(clf, batch_max_wait_ms=50) as c:
        from concurrent.futures import ThreadPoolExecutor

        def call(_):
            return c.post("/v1/classify", files={"file": ("a.png", png_bytes(), "image/png")})

        with ThreadPoolExecutor(8) as ex:
            rs = list(ex.map(call, range(16)))
        assert all(r.status_code == 200 and "label" in r.json() for r in rs)
        m = c.get("/metrics").text
        assert "inference_batch_size_count" in m


def test_classifier_disabled_returns_503():
    with make_client() as c:
        assert c.post("/v1/classify", files={"file": ("a.png", png_bytes(), "image/png")}).status_code == 503


def test_input_validation():
    with make_client(max_upload_bytes=1000) as c:
        assert c.post("/v1/ocr", files={"file": ("a.txt", b"hi", "text/plain")}).status_code == 415
        assert c.post("/v1/ocr", files={"file": ("a.png", b"not an image", "image/png")}).status_code == 400
        assert c.post("/v1/ocr", files={"file": ("a.png", png_bytes(500, 500), "image/png")}).status_code == 413
    with make_client(max_image_pixels=100) as c:
        assert c.post("/v1/ocr", files={"file": ("a.png", png_bytes(), "image/png")}).status_code == 413


def test_api_key_enforced():
    with make_client(api_key="secret") as c:
        f = {"file": ("a.png", png_bytes(), "image/png")}
        assert c.post("/v1/ocr", files=f).status_code == 401
        assert c.post("/v1/ocr", files=f, headers={"x-api-key": "wrong"}).status_code == 401
        assert c.post("/v1/ocr", files=f, headers={"x-api-key": "secret"}).status_code == 200
        assert c.get("/health").status_code == 200   # health stays open for load balancers


# ----------------------------------------------------------------------------- VLM proxy
def _vlm(handler):
    return VLMClient("http://vllm", "test-model", 5, transport=httpx.MockTransport(handler))


def test_vlm_proxy_success_and_payload():
    seen = {}

    def handler(req: httpx.Request):
        seen["body"] = json.loads(req.content)
        return httpx.Response(200, json={"choices": [{"message": {"content": '{"total": "500"}'}}]})

    with make_client(vlm=_vlm(handler)) as c:
        r = c.post("/v1/vlm/extract", files={"file": ("a.png", png_bytes(), "image/png")}, data={"prompt": "get total"})
    assert r.status_code == 200 and r.json()["output"] == '{"total": "500"}'
    content = seen["body"]["messages"][0]["content"]
    assert content[0]["image_url"]["url"].startswith("data:image/png;base64,")
    assert content[1]["text"] == "get total" and seen["body"]["temperature"] == 0.0


def test_vlm_upstream_errors_mapped():
    with make_client(vlm=_vlm(lambda r: httpx.Response(500))) as c:
        assert c.post("/v1/vlm/extract", files={"file": ("a.png", png_bytes(), "image/png")}).status_code == 502

    def timeout(req):
        raise httpx.ReadTimeout("slow")

    with make_client(vlm=_vlm(timeout)) as c:
        assert c.post("/v1/vlm/extract", files={"file": ("a.png", png_bytes(), "image/png")}).status_code == 504

    with make_client() as c:
        assert c.post("/v1/vlm/extract", files={"file": ("a.png", png_bytes(), "image/png")}).status_code == 503


def test_mask_pii():
    t = mask_pii("PAN ABCDE1234F mail a.b@x.com ph 9876543210 aadhaar 1234 5678 9012")
    for leaked in ("ABCDE1234F", "a.b@x.com", "9876543210", "5678"):
        assert leaked not in t
