import dummy_onnx
from benchmark_inference import bench


def test_benchmark_runs_on_cpu(tmp_path):
    p = dummy_onnx.build(str(tmp_path / "m.onnx"))
    r = bench(p, "CPUExecutionProvider", batch=4, iters=3, warmup=1)
    assert r["throughput_img_s"] > 0 and r["p95_ms"] >= r["p50_ms"]
