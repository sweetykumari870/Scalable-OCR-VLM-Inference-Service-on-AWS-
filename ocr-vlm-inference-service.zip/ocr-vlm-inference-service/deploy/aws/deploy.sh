#!/usr/bin/env bash
# Build -> push to ECR -> register new task definition -> roll the ECS service.
# Prereqs: aws cli v2 configured, docker, jq.
set -euo pipefail

: "${AWS_REGION:?set AWS_REGION}"
: "${AWS_ACCOUNT_ID:?set AWS_ACCOUNT_ID}"
REPO="${ECR_REPO:-ocr-vlm-inference}"
CLUSTER="${ECS_CLUSTER:-ml-platform}"
SERVICE="${ECS_SERVICE:-ocr-vlm-inference}"
DOCKERFILE="${DOCKERFILE:-Dockerfile.gpu}"
TAG="$(git rev-parse --short HEAD 2>/dev/null || date +%s)"
REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
IMAGE="${REGISTRY}/${REPO}:${TAG}"

aws ecr describe-repositories --repository-names "$REPO" --region "$AWS_REGION" >/dev/null 2>&1 \
  || aws ecr create-repository --repository-name "$REPO" --region "$AWS_REGION" \
       --image-scanning-configuration scanOnPush=true >/dev/null

aws ecr get-login-password --region "$AWS_REGION" | docker login --username AWS --password-stdin "$REGISTRY"
docker build -f "$DOCKERFILE" -t "$IMAGE" .
docker push "$IMAGE"

TASK_DEF=$(sed -e "s|<ACCOUNT_ID>|${AWS_ACCOUNT_ID}|g" -e "s|<REGION>|${AWS_REGION}|g" \
               -e "s|ocr-vlm-inference:latest|${REPO}:${TAG}|g" deploy/aws/ecs-task-definition.json)
NEW_ARN=$(aws ecs register-task-definition --region "$AWS_REGION" --cli-input-json "$TASK_DEF" \
          | jq -r '.taskDefinition.taskDefinitionArn')

aws ecs update-service --region "$AWS_REGION" --cluster "$CLUSTER" --service "$SERVICE" \
    --task-definition "$NEW_ARN" --force-new-deployment >/dev/null
echo "Deployed $IMAGE -> $SERVICE ($NEW_ARN)"
