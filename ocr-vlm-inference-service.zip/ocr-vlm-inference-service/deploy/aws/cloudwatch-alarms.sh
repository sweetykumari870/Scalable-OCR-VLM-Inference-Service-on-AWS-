#!/usr/bin/env bash
# CloudWatch metric filters + alarms built from the service's JSON logs (fields: status, latency_ms).
# Usage: AWS_REGION=ap-south-1 SNS_TOPIC_ARN=arn:aws:sns:... ./cloudwatch-alarms.sh
set -euo pipefail
: "${AWS_REGION:?}"; : "${SNS_TOPIC_ARN:?}"
GROUP="/ecs/ocr-vlm-inference"
NS="OcrVlmService"

aws logs put-metric-filter --region "$AWS_REGION" --log-group-name "$GROUP" \
  --filter-name server-errors \
  --filter-pattern '{ $.msg = "request" && $.status >= 500 }' \
  --metric-transformations metricName=Http5xx,metricNamespace=$NS,metricValue=1,defaultValue=0

aws logs put-metric-filter --region "$AWS_REGION" --log-group-name "$GROUP" \
  --filter-name slow-requests \
  --filter-pattern '{ $.msg = "request" && $.latency_ms > 2000 }' \
  --metric-transformations metricName=SlowRequests,metricNamespace=$NS,metricValue=1,defaultValue=0

aws cloudwatch put-metric-alarm --region "$AWS_REGION" --alarm-name ocr-vlm-5xx \
  --namespace $NS --metric-name Http5xx --statistic Sum --period 60 --evaluation-periods 5 \
  --threshold 5 --comparison-operator GreaterThanOrEqualToThreshold \
  --treat-missing-data notBreaching --alarm-actions "$SNS_TOPIC_ARN"

aws cloudwatch put-metric-alarm --region "$AWS_REGION" --alarm-name ocr-vlm-slow \
  --namespace $NS --metric-name SlowRequests --statistic Sum --period 60 --evaluation-periods 5 \
  --threshold 20 --comparison-operator GreaterThanOrEqualToThreshold \
  --treat-missing-data notBreaching --alarm-actions "$SNS_TOPIC_ARN"
echo "alarms created"
