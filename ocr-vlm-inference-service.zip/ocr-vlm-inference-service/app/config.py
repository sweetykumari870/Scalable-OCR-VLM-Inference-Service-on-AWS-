"""Runtime configuration from environment variables."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import List


def _labels() -> List[str]:
    raw = os.getenv("CLASSIFIER_LABELS", "invoice,bank_statement,id_card,salary_slip")
    return [x.strip() for x in raw.split(",") if x.strip()]


@dataclass
class Settings:
    api_key: str = os.getenv("API_KEY", "")                       # empty = auth disabled (dev only)
    max_upload_bytes: int = int(os.getenv("MAX_UPLOAD_BYTES", 10 * 1024 * 1024))
    max_image_pixels: int = int(os.getenv("MAX_IMAGE_PIXELS", 40_000_000))
    ocr_concurrency: int = int(os.getenv("OCR_CONCURRENCY", 4))
    batch_max_size: int = int(os.getenv("BATCH_MAX_SIZE", 16))
    batch_max_wait_ms: float = float(os.getenv("BATCH_MAX_WAIT_MS", 10))
    classifier_path: str = os.getenv("CLASSIFIER_PATH", "")       # path to .onnx; empty = disabled
    classifier_labels: List[str] = field(default_factory=_labels)
    onnx_providers: str = os.getenv("ONNX_PROVIDERS", "CUDAExecutionProvider,CPUExecutionProvider")
    vlm_url: str = os.getenv("VLM_URL", "")                       # e.g. http://vllm:8000
    vlm_model: str = os.getenv("VLM_MODEL", "Qwen/Qwen2-VL-2B-Instruct")
    vlm_timeout_s: float = float(os.getenv("VLM_TIMEOUT_S", 60))
    log_level: str = os.getenv("LOG_LEVEL", "INFO")
