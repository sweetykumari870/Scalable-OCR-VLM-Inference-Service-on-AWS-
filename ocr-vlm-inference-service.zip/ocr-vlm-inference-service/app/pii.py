"""PII masking. Applied to anything that is logged, and optionally to API responses."""
import re

_PAN = re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b")
_GSTIN = re.compile(r"\b\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]\b")
_AADHAAR = re.compile(r"\b\d{4}\s?\d{4}\s?\d{4}\b")
_CARD = re.compile(r"\b(?:\d[ -]?){13,16}\b")
_EMAIL = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
_PHONE = re.compile(r"(?<!\d)(?:\+91[ -]?)?[6-9]\d{9}(?!\d)")


def mask_pii(text: str) -> str:
    text = _EMAIL.sub("[EMAIL]", text)
    text = _GSTIN.sub("[GSTIN]", text)
    text = _PAN.sub("[PAN]", text)
    text = _CARD.sub("[CARD]", text)
    text = _AADHAAR.sub("[ID]", text)
    text = _PHONE.sub("[PHONE]", text)
    return text
