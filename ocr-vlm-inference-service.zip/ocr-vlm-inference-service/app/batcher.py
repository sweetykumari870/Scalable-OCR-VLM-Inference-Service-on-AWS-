"""Dynamic micro-batching: collect requests for up to `max_wait_ms` or `max_batch_size`,
run them through the model together, then fan results back out to each caller.

This is what turns many small GPU calls into a few large ones (higher throughput at a
bounded latency cost). Triton's dynamic_batching does the same thing server-side.
"""
from __future__ import annotations

import asyncio
import time
from typing import Any, Callable, List, Optional

from .metrics import Metrics


class MicroBatcher:
    def __init__(self, fn: Callable[[List[Any]], List[Any]], max_batch_size: int = 16,
                 max_wait_ms: float = 10.0, name: str = "model", metrics: Optional[Metrics] = None):
        self.fn, self.max_batch_size, self.max_wait = fn, max_batch_size, max_wait_ms / 1000.0
        self.name, self.metrics = name, metrics
        self._queue: "asyncio.Queue" = asyncio.Queue()
        self._task: Optional[asyncio.Task] = None

    async def start(self) -> None:
        self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    async def submit(self, item: Any) -> Any:
        fut = asyncio.get_running_loop().create_future()
        await self._queue.put((item, fut))
        return await fut

    async def _run(self) -> None:
        loop = asyncio.get_running_loop()
        while True:
            first = await self._queue.get()
            batch = [first]
            deadline = loop.time() + self.max_wait
            while len(batch) < self.max_batch_size:
                remaining = deadline - loop.time()
                if remaining <= 0:
                    break
                try:
                    batch.append(await asyncio.wait_for(self._queue.get(), remaining))
                except asyncio.TimeoutError:
                    break
            items = [b[0] for b in batch]
            t0 = time.perf_counter()
            try:
                results = await loop.run_in_executor(None, self.fn, items)
                if len(results) != len(items):
                    raise RuntimeError("batch fn returned wrong number of results")
                for (_, fut), res in zip(batch, results):
                    if not fut.done():
                        fut.set_result(res)
            except Exception as e:  # noqa: BLE001 - propagate to every caller in the batch
                if self.metrics:
                    self.metrics.failures.labels(self.name).inc()
                for _, fut in batch:
                    if not fut.done():
                        fut.set_exception(e)
            finally:
                if self.metrics:
                    self.metrics.batch_size.labels(self.name).observe(len(items))
                    self.metrics.model_seconds.labels(self.name).observe(time.perf_counter() - t0)
