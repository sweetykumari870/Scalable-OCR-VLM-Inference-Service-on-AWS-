"""Prometheus metrics (per-app registry so tests can create many apps)."""
from prometheus_client import CollectorRegistry, Counter, Gauge, Histogram, generate_latest

LATENCY_BUCKETS = (0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, 30, 60)


class Metrics:
    def __init__(self):
        self.registry = CollectorRegistry()
        self.requests = Counter("http_requests_total", "Requests", ["endpoint", "status"], registry=self.registry)
        self.latency = Histogram("http_request_seconds", "Request latency", ["endpoint"],
                                 buckets=LATENCY_BUCKETS, registry=self.registry)
        self.in_flight = Gauge("http_in_flight_requests", "In-flight requests", registry=self.registry)
        self.batch_size = Histogram("inference_batch_size", "Batch sizes", ["model"],
                                    buckets=(1, 2, 4, 8, 16, 32, 64), registry=self.registry)
        self.model_seconds = Histogram("model_inference_seconds", "Model time per batch", ["model"],
                                       buckets=LATENCY_BUCKETS, registry=self.registry)
        self.failures = Counter("inference_failures_total", "Inference failures", ["model"], registry=self.registry)

    def render(self) -> bytes:
        return generate_latest(self.registry)
