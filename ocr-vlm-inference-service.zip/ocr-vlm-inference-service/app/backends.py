"""Model backends: Tesseract OCR and an ONNX Runtime document classifier."""
from __future__ import annotations

from typing import Dict, List, Sequence

import cv2
import numpy as np


# ----------------------------------------------------------------------------- OCR
def preprocess_for_ocr(img: np.ndarray) -> np.ndarray:
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
    gray = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(gray)
    return cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 15)


class TesseractBackend:
    name = "tesseract"

    def __init__(self, lang: str = "eng", psm: int = 6):
        self.lang, self.psm = lang, psm

    def run(self, image: np.ndarray, preprocess: bool = True) -> Dict:
        import pytesseract

        if preprocess:
            image = preprocess_for_ocr(image)
        d = pytesseract.image_to_data(image, lang=self.lang, config=f"--psm {self.psm}",
                                      output_type=pytesseract.Output.DICT)
        words, confs, lines = [], [], {}
        for i, t in enumerate(d["text"]):
            t = t.strip()
            if not t or float(d["conf"][i]) < 0:
                continue
            words.append(t)
            confs.append(float(d["conf"][i]) / 100)
            lines.setdefault((d["block_num"][i], d["par_num"][i], d["line_num"][i]), []).append(t)
        return {
            "text": "\n".join(" ".join(v) for _, v in sorted(lines.items())),
            "n_words": len(words),
            "mean_conf": float(np.mean(confs)) if confs else 0.0,
        }


# ----------------------------------------------------------------------------- classifier
def softmax(x: np.ndarray) -> np.ndarray:
    e = np.exp(x - x.max(axis=1, keepdims=True))
    return e / e.sum(axis=1, keepdims=True)


class OnnxClassifier:
    """Image classifier served with ONNX Runtime. Input [N,3,H,W] float32 -> logits [N,C]."""

    name = "doc_classifier"

    def __init__(self, path: str, labels: Sequence[str], providers: str = "CUDAExecutionProvider,CPUExecutionProvider"):
        import onnxruntime as ort

        wanted = [p.strip() for p in providers.split(",") if p.strip()]
        avail = ort.get_available_providers()
        chosen = [p for p in wanted if p in avail] or ["CPUExecutionProvider"]
        so = ort.SessionOptions()
        so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        self.session = ort.InferenceSession(path, sess_options=so, providers=chosen)
        inp = self.session.get_inputs()[0]
        self.input_name = inp.name
        h, w = inp.shape[2], inp.shape[3]
        self.size = (w if isinstance(w, int) else 224, h if isinstance(h, int) else 224)
        self.labels = list(labels)
        self.providers = self.session.get_providers()

    def _prep(self, img: np.ndarray) -> np.ndarray:
        if img.ndim == 2:
            img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
        img = cv2.resize(img, self.size, interpolation=cv2.INTER_AREA)
        x = cv2.cvtColor(img, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
        x = (x - np.array([0.485, 0.456, 0.406], np.float32)) / np.array([0.229, 0.224, 0.225], np.float32)
        return x.transpose(2, 0, 1)

    def predict_batch(self, images: List[np.ndarray]) -> List[Dict]:
        batch = np.stack([self._prep(i) for i in images]).astype(np.float32)
        logits = self.session.run(None, {self.input_name: batch})[0]
        probs = softmax(logits)
        out = []
        for p in probs:
            k = int(p.argmax())
            label = self.labels[k] if k < len(self.labels) else str(k)
            out.append({"label": label, "confidence": float(p[k]),
                        "scores": {(self.labels[i] if i < len(self.labels) else str(i)): float(v) for i, v in enumerate(p)}})
        return out
