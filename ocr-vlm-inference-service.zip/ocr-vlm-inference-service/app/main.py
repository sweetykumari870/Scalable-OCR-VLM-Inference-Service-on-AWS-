"""FastAPI inference service: OCR, document classification (batched ONNX) and VLM extraction (vLLM)."""
from __future__ import annotations

import asyncio
import hmac
import logging
import time
import uuid
from contextlib import asynccontextmanager
from typing import Optional

import cv2
import numpy as np
from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, Query, Request, Response, UploadFile

from .backends import OnnxClassifier, TesseractBackend
from .batcher import MicroBatcher
from .config import Settings
from .logging_conf import log_extra, setup_logging
from .metrics import Metrics
from .pii import mask_pii
from .vlm import VLMClient, VLMError

log = logging.getLogger("service")
ALLOWED_MIME = {"image/png", "image/jpeg", "image/tiff", "image/bmp", "image/webp"}


def create_app(settings: Optional[Settings] = None, ocr_backend=None, classifier=None, vlm_client=None) -> FastAPI:
    s = settings or Settings()
    setup_logging(s.log_level)
    metrics = Metrics()
    state = {"ocr": ocr_backend or TesseractBackend(), "classifier": classifier, "vlm": vlm_client, "batcher": None}
    ocr_sem = asyncio.Semaphore(s.ocr_concurrency)

    if state["classifier"] is None and s.classifier_path:
        state["classifier"] = OnnxClassifier(s.classifier_path, s.classifier_labels, s.onnx_providers)
    if state["vlm"] is None and s.vlm_url:
        state["vlm"] = VLMClient(s.vlm_url, s.vlm_model, s.vlm_timeout_s)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if state["classifier"] is not None:
            state["batcher"] = MicroBatcher(state["classifier"].predict_batch, s.batch_max_size,
                                            s.batch_max_wait_ms, "doc_classifier", metrics)
            await state["batcher"].start()
        yield
        if state["batcher"]:
            await state["batcher"].stop()
        if state["vlm"]:
            await state["vlm"].close()

    app = FastAPI(title="OCR / VLM Inference Service", version="0.1.0", lifespan=lifespan)

    # -------------------------------------------------------------- auth + middleware
    def require_key(x_api_key: str = Header(default="")):
        if s.api_key and not hmac.compare_digest(x_api_key, s.api_key):
            raise HTTPException(401, "invalid or missing API key")

    @app.middleware("http")
    async def observe(request: Request, call_next):
        rid = request.headers.get("x-request-id", uuid.uuid4().hex[:12])
        endpoint = request.url.path
        metrics.in_flight.inc()
        t0 = time.perf_counter()
        status = 500
        try:
            response = await call_next(request)
            status = response.status_code
            response.headers["x-request-id"] = rid
            return response
        finally:
            dt = time.perf_counter() - t0
            metrics.in_flight.dec()
            if endpoint != "/metrics":
                metrics.requests.labels(endpoint, str(status)).inc()
                metrics.latency.labels(endpoint).observe(dt)
                log.info("request", extra=log_extra(request_id=rid, path=endpoint, status=status, latency_ms=round(dt * 1000, 1)))

    # -------------------------------------------------------------- helpers
    async def read_image(file: UploadFile):
        if file.content_type not in ALLOWED_MIME:
            raise HTTPException(415, f"unsupported content type {file.content_type!r}")
        data = await file.read(s.max_upload_bytes + 1)
        if len(data) > s.max_upload_bytes:
            raise HTTPException(413, "file too large")
        img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
        if img is None:
            raise HTTPException(400, "could not decode image")
        if img.shape[0] * img.shape[1] > s.max_image_pixels:
            raise HTTPException(413, "image resolution too large")
        return data, img

    # -------------------------------------------------------------- endpoints
    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.get("/ready")
    async def ready():
        return {
            "ocr": state["ocr"] is not None,
            "classifier": state["classifier"] is not None,
            "vlm": state["vlm"] is not None,
            "providers": getattr(state["classifier"], "providers", None),
        }

    @app.get("/metrics")
    async def prometheus():
        return Response(metrics.render(), media_type="text/plain; version=0.0.4")

    @app.post("/v1/ocr", dependencies=[Depends(require_key)])
    async def ocr(file: UploadFile = File(...), preprocess: bool = Query(True), mask: bool = Query(False)):
        _, img = await read_image(file)
        async with ocr_sem:
            try:
                res = await asyncio.get_running_loop().run_in_executor(None, state["ocr"].run, img, preprocess)
            except Exception:
                metrics.failures.labels("ocr").inc()
                log.exception("ocr failed")
                raise HTTPException(500, "OCR failed")
        log.info("ocr_done", extra=log_extra(n_words=res["n_words"], mean_conf=round(res["mean_conf"], 3)))  # never log raw text
        if mask:
            res = {**res, "text": mask_pii(res["text"])}
        return res

    @app.post("/v1/classify", dependencies=[Depends(require_key)])
    async def classify(file: UploadFile = File(...)):
        if state["batcher"] is None:
            raise HTTPException(503, "classifier not configured (set CLASSIFIER_PATH)")
        _, img = await read_image(file)
        try:
            return await state["batcher"].submit(img)
        except Exception:
            log.exception("classification failed")
            raise HTTPException(500, "classification failed")

    @app.post("/v1/vlm/extract", dependencies=[Depends(require_key)])
    async def vlm_extract(
        file: UploadFile = File(...),
        prompt: str = Form("Extract the invoice number, date and total amount. Reply with JSON only."),
        max_tokens: int = Form(512),
    ):
        if state["vlm"] is None:
            raise HTTPException(503, "VLM backend not configured (set VLM_URL)")
        data, _ = await read_image(file)
        t0 = time.perf_counter()
        try:
            out = await state["vlm"].extract(data, file.content_type, prompt, min(max_tokens, 2048))
        except VLMError as e:
            metrics.failures.labels("vlm").inc()
            raise HTTPException(e.status, e.detail)
        return {"output": out, "latency_ms": round((time.perf_counter() - t0) * 1000, 1)}

    return app


app = create_app()
