"""Client for a vLLM (OpenAI-compatible) Vision-Language Model server."""
from __future__ import annotations

import base64
from typing import Optional

import httpx


class VLMError(Exception):
    def __init__(self, status: int, detail: str):
        super().__init__(detail)
        self.status, self.detail = status, detail


class VLMClient:
    def __init__(self, base_url: str, model: str, timeout_s: float = 60.0, transport: Optional[httpx.AsyncBaseTransport] = None):
        self.model = model
        self.client = httpx.AsyncClient(base_url=base_url.rstrip("/"), timeout=timeout_s, transport=transport)

    async def close(self) -> None:
        await self.client.aclose()

    async def extract(self, image_bytes: bytes, mime: str, prompt: str, max_tokens: int = 512) -> str:
        data_url = f"data:{mime};base64,{base64.b64encode(image_bytes).decode()}"
        body = {
            "model": self.model,
            "temperature": 0.0,
            "max_tokens": max_tokens,
            "messages": [{"role": "user", "content": [
                {"type": "image_url", "image_url": {"url": data_url}},
                {"type": "text", "text": prompt},
            ]}],
        }
        try:
            r = await self.client.post("/v1/chat/completions", json=body)
        except httpx.TimeoutException:
            raise VLMError(504, "VLM server timed out")
        except httpx.HTTPError as e:
            raise VLMError(502, f"VLM server unreachable: {type(e).__name__}")
        if r.status_code >= 400:
            raise VLMError(502, f"VLM server returned {r.status_code}")
        return r.json()["choices"][0]["message"]["content"]
